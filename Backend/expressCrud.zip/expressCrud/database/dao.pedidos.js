const db = require('./config')

let operations = {
    list: function(){
        return db.promise().query('SELECT * FROM pedidos')
    },
    findById(idProduto){
        return db.promise().query('SELECT * FROM pedidos where idProduto=?', [idProduto])
    },
    save: function(produtos){
        return db.promise().execute('INSERT INTO pedidos (descricao, nomeProduto, modelo, marca, preco, cor, dimensoes, peso, capacidade, processador, tela, sistema_operacional, conectividade, portas_entradas, bateria, voltagem, data_lancamento, quantidade, status_disponibilidade, idCategoria, idFornecedor) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?', 
            [descricao, nomeProduto, modelo, marca, preco, cor, dimensoes, peso, capacidade, processador, tela, sistema_operacional, conectividade, portas_entradas, bateria, voltagem, data_lancamento, quantidade, status_disponibilidade, idCategoria, idFornecedor])
    },
    update: function(produtos){
        return db.promise().execute('UPDATE pedidos set descricao , nomeProduto = ?, modelo = ?, marca = ?, preco = ?, cor = ?, dimensoes = ?, peso = ?, capacidade = ?, processador = ?, tela = ?, sistema_operacional = ?, conectividade = ?, portas_entradas = ?, bateria = ?, voltagem = ?, data_lancamento = ?, quantidade = ?, status_disponibilidade = ?, idCategoria = ?, idFornecedor = ?, where idProduto = ?', 
            [descricao, nomeProduto, modelo, marca, preco, cor, dimensoes, peso, capacidade, processador, tela, sistema_operacional, conectividade, portas_entradas, bateria, voltagem, data_lancamento, quantidade, status_disponibilidade, idCategoria, idFornecedor])
    },
    remove: function(idProduto){
        return db.promise().execute('DELETE FROM pedidos WHERE idProduto = ?', [idProduto])
    },
}

module.exports = operations